--------------------------------------------------------------------------------
-- Registry Access
--------------------------------------------------------------------------------
DECLARE @value NVARCHAR(4000)
EXEC dbo.GetRegistryEntry @keyName = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSSQLServer\Setup',
                          @valueName = 'SQLPath',
                          @rtnValue = @value OUT
PRINT @value
GO

--------------------------------------------------------------------------------
-- Webservice Access
--------------------------------------------------------------------------------
DECLARE @value NVARCHAR(4000)
EXEC dbo.ProcWebServiceHelloWold @address = 'http://localhost/test.html',
                                 @rtnValue = @value OUT
PRINT @value
GO

--------------------------------------------------------------------------------
-- Data Access
--------------------------------------------------------------------------------
EXEC dbo.GetRandomLetter
GO


/*******************************************************************************
Code Access Security: (SAFE | EXTERNAL_ACCESS | UNSAFE)
http://msdn.microsoft.com/en-us/library/ms345101.aspx
*******************************************************************************/