SELECT dbo.ConcatenateWithComma(Letter)
FROM Letters
WHERE Asciicode > 0


SELECT a, dbo.ConcatenateWithComma(b)
FROM (
    VALUES ('bit', 'true'),
           ('bit', 'false'),
           ('tinyint', '0'),
           ('tinyint', '1'),
           ('tinyint', '01'),
           ('tinyint', '255'),
           ('smallint', '256'),
           ('smallint', '-1'),
           ('smallint', '10'),
           ('decimal', '10.1'),
           ('int', '2147483647'),
           ('bigint', '4294967296'),
           ('bigint', '4,294,967,296'),
           ('datetime', '2011-06-30'),
           ('datetime', '6/30/11')
    ) AS MyTable(a, b)
GROUP BY a