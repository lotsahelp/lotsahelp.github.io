SELECT a,
       b,
       ISNUMERIC(b) AS isNumeric,
       ISDATE(b) AS isDate
FROM (
    VALUES ('bit', 'true'),
           ('bit', 'false'),
           ('tinyint', '0'),
           ('tinyint', '1'),
           ('tinyint', '01'),
           ('tinyint', '255'),
           ('smallint', '256'),
           ('smallint', '-1'),
           ('smallint', '10'),
           ('decimal', '10.1'),
           ('int', '2147483647'),
           ('bigint', '4294967296'),
           ('bigint', '4,294,967,296'),
           ('datetime', '2011-06-30'),
           ('datetime', '6/30/11')
    ) AS MyTable(a, b);


SELECT a,
       b,
       CAST(b AS smallint)
FROM (
    VALUES ('smallint', '10'),
           ('decimal', '10.1')
    ) AS MyTable(a, b)
WHERE ISNUMERIC(b) = 1;





--------------------------------------------------------------------------------
-- A CLR Alternative
--------------------------------------------------------------------------------

SELECT a,
       b,
       dbo.ParseBit(b) AS ParseBit,
       dbo.ParseTinyInt(b) AS ParseTinyInt,
       dbo.ParseSmallInt(b) AS ParseSmallInt,
       dbo.ParseInt(b) AS ParseInt,
       dbo.ParseBigInt(b) AS ParseBigInt,
       dbo.ParseDateTime(b) AS ParseDateTime
FROM (
    VALUES ('bit', 'true'),
           ('bit', 'false'),
           ('tinyint', '0'),
           ('tinyint', '1'),
           ('tinyint', '01'),
           ('tinyint', '255'),
           ('smallint', '256'),
           ('smallint', '-1'),
           ('smallint', '10'),
           ('int', '2147483647'),
           ('bigint', '4294967296'),
           ('datetime', '2011-06-30'),
           ('datetime', '6/30/11')
    ) AS MyTable(a, b);