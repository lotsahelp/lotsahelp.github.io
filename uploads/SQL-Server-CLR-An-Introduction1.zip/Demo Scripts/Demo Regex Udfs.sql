SET NOCOUNT ON;

--------------------------------------------------------------------------------
-- RegexMatch
--------------------------------------------------------------------------------
DECLARE @RegexMatch TABLE (x nvarchar(4000))
DECLARE @i INT, @start DATETIME2, @duration INT

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 10000
BEGIN
	INSERT INTO @RegexMatch(x)
	SELECT a
	FROM (
		VALUES ('Dallas Tech Fest'),
		       ('Eric Humphrey'),
		       ('lotsahelp1337'),
		       ('1a2b3c4d5e')
		) AS MyTable(a)
	WHERE a LIKE '%[0-9]%'

	DELETE @RegexMatch
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('SQL Took %u ms', 10, 1, @duration)

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 10000
BEGIN
	INSERT INTO @RegexMatch(x)
	SELECT a
	FROM (
		VALUES ('Dallas Tech Fest'),
		       ('Eric Humphrey'),
		       ('lotsahelp1337'),
		       ('1a2b3c4d5e')
		) AS MyTable(a)
	WHERE dbo.RegexMatch('\d', a) = 1;

	DELETE @RegexMatch
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('CLR Took %u ms', 10, 1, @duration)
GO



--------------------------------------------------------------------------------
-- Numeric Chars
--------------------------------------------------------------------------------
DECLARE @NumericChars TABLE (x nvarchar(4000))
DECLARE @i INT, @start DATETIME2, @duration INT

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 10000
BEGIN
	INSERT INTO @NumericChars(x)
	SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(a, '0', ''), '1', ''), '2', ''), '3', ''), '4', ''), '5', ''), '6', ''), '7', ''), '8', ''), '9', '')
	FROM (
		VALUES ('Dallas Tech Fest'),
		       ('Eric Humphrey'),
		       ('lotsahelp1337'),
		       ('1a2b3c4d5e')
		) AS MyTable(a);

	DELETE @NumericChars
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('SQL Took %u ms', 10, 1, @duration)

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 10000
BEGIN
	INSERT INTO @NumericChars(x)
	SELECT dbo.RegexReplace('\D', a, '')
	--SELECT dbo.GetNumericChars(a)
	FROM (
		VALUES ('Dallas Tech Fest'),
		       ('Eric Humphrey'),
		       ('lotsahelp1337'),
		       ('1a2b3c4d5e')
		) AS MyTable(a);

	DELETE @NumericChars
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('CLR Took %u ms', 10, 1, @duration)
GO
