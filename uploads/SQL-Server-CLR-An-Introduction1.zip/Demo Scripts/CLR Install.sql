CREATE ASSEMBLY SqlServerProject1
FROM 'C:\Users\erich\Documents\visual studio 2010\Projects\SqlServerProject1\SqlServerProject1\bin\Release\SqlServerProject1.dll'
GO



select * from sys.assemblies
select * from sys.assembly_files
GO



CREATE PROCEDURE HelloDallasTechFest(@rtnValue nvarchar(4000) OUTPUT)
AS EXTERNAL NAME SqlServerProject1.ProcHelloDallasTechFest.HelloDallasTechFest;
GO



DECLARE @value nvarchar(4000)
EXEC HelloDallasTechFest @value out
PRINT @value
GO