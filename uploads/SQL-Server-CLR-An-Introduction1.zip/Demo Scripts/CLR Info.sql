sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO

sp_configure 'clr enabled', 1;
GO
RECONFIGURE;
GO


select * from sys.dm_clr_properties
select * from sys.dm_clr_appdomains
select * from sys.dm_clr_loaded_assemblies
select * from sys.dm_clr_tasks
select * from Tools.sys.assemblies
select * from Tools.sys.assembly_files
go




--ALTER DATABASE Tools
--SET TRUSTWORTHY ON