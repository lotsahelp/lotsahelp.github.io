SET NOCOUNT ON;

--------------------------------------------------------------------------------
-- Simple Addition
--------------------------------------------------------------------------------
DECLARE @Addition TABLE (x int)
DECLARE @i INT, @start DATETIME2, @duration INT

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 100
BEGIN
	INSERT INTO @Addition(x)
	SELECT n1.Num + n2.Num
	FROM Numbers n1, Numbers n2
	WHERE n1.Num < 100
	  AND n2.Num < 100

	DELETE @Addition
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('SQL Took %u ms', 10, 1, @duration)

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 100
BEGIN
	INSERT INTO @Addition(x)
	SELECT dbo.SimpleAdd(n1.Num, n2.Num)
	FROM Numbers n1, Numbers n2
	WHERE n1.Num < 100
	  AND n2.Num < 100

	DELETE @Addition
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('CLR Took %u ms', 10, 1, @duration)
GO


--------------------------------------------------------------------------------
-- Recursive Function
--------------------------------------------------------------------------------
DECLARE @Factorials TABLE (x int, y bigint)
DECLARE @i INT, @start DATETIME2, @duration INT

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 10000
BEGIN
	INSERT INTO @Factorials(x, y)
	SELECT Num, dbo.FactorialSQL(Num)
	FROM Numbers
	WHERE Num < 21

	DELETE @Factorials
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('SQL Took %u ms', 10, 1, @duration)

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 10000
BEGIN
	INSERT INTO @Factorials(x, y)
	SELECT Num, dbo.Factorial(Num)
	FROM Numbers
	WHERE Num < 21

	DELETE @Factorials
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('CLR Took %u ms', 10, 1, @duration)
GO



--------------------------------------------------------------------------------
-- Amortization
--------------------------------------------------------------------------------
DECLARE @Amortization TABLE (x money, y money)
DECLARE @i INT, @start DATETIME2, @duration INT

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 10000
BEGIN
	INSERT INTO @Amortization(x, y)
	SELECT CAST(Num AS money) * 0.125,
		   dbo.AmortizationCalculatorForPaymentSQL(100000, CAST(Num AS money) * 0.125 / 100., 360)
	FROM Numbers
	WHERE Num BETWEEN 32 AND 56

	DELETE @Amortization
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('SQL Took %u ms', 10, 1, @duration)

SELECT @i = 0, @start = SYSDATETIME()
WHILE @i < 10000
BEGIN
	INSERT INTO @Amortization(x, y)
	SELECT CAST(Num AS money) * 0.125,
		   dbo.AmortizationCalculatorForPayment(100000, CAST(Num AS money) * 0.125 / 100., 360)
	FROM Numbers
	WHERE Num BETWEEN 32 AND 56

	DELETE @Amortization
	SET @i += 1
END
SET @duration = DATEDIFF(ms, @start, SYSDATETIME())
RAISERROR('CLR Took %u ms', 10, 1, @duration)
GO
